import zipfile, posixpath, json
from pathlib import Path
from xml.etree import ElementTree as ET
b=Path('.presentation-build'); file=b/'CRUD_interactivo_borrador.pptx'
ns={'a':'http://schemas.openxmlformats.org/drawingml/2006/main','p':'http://schemas.openxmlformats.org/presentationml/2006/main','r':'http://schemas.openxmlformats.org/package/2006/relationships'}
slides=json.loads((b/'slides.json').read_text()); count=0; alltargets=set(); image_count=0
with zipfile.ZipFile(file) as z:
    for i,s in enumerate(slides,1):
        root=ET.fromstring(z.read(f'ppt/slides/slide{i}.xml')); rels=ET.fromstring(z.read(f'ppt/slides/_rels/slide{i}.xml.rels')); rel={r.attrib['Id']:r.attrib for r in rels}
        for h in root.findall('.//a:hlinkClick',ns):
            rid=h.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']; r=rel[rid]
            assert r['Type'].endswith('/slide')
            target=posixpath.normpath('ppt/slides/'+r['Target']); assert target in z.namelist(),target
            count+=1; alltargets.add(target)
        if s['kind']=='code':
            assert root.find('.//p:pic',ns) is not None
            image_count+=1
            for source in s['refs']:
                file,rng=source.rsplit(':',1); a,c=map(int,rng.split('–')); assert c<=len(Path(file).read_text().splitlines())
    assert len(slides)==33 and len(alltargets)==33 and image_count==12
print(f'Correcto: {count} acciones de enlace, 33 destinos existentes, 12 capturas y referencias a líneas verificadas.')
(b/'links-validation.txt').write_text(f'{count} acciones verificadas. Todos los destinos y referencias a código existen.\n')
