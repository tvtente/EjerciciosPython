from pathlib import Path
import json
b=Path('.presentation-build')
slides=json.loads((b/'slides.json').read_text())
# The first presentation and its authoring files stay available unchanged.
def seq(id,title,rows,note,code,lanes=None):
    return dict(id=id,title=title,subtitle='Las flechas se leen de arriba abajo. Pulsa un nombre para abrir el código o la explicación.',kind='sequence',rows=rows,note=note,code=code,back=code,lanes=lanes or [['Interfaz','ui'],['TodoState','state'],['TodoRepository','repo'],['SQLite','engine']])
# Each row records sender, receiver, exact called symbol or summarized database action,
# destination of the clickable label, and whether it represents a result.
init=seq('flow_init','Diagrama · Inicialización de la BDD',[
[0,1,'TodoRepository()','repo_code',False], [1,2,'get_engine()','db_code',False], [2,1,'engine','engine',True],
[0,1,'initialize()','repo_code',False], [1,2,'init_database()','db_code',False], [2,3,'metadata.create_all()','init',False], [3,2,'tablas disponibles','init',True]],
'load_todos() crea el repositorio y después llama a initialize(). Importar Todo registra la tabla antes de create_all().','db_code',
[['TodoState','state'],['TodoRepository','repo'],['database.py','engine'],['SQLModel / SQLite','init']])
create=seq('flow_create','Diagrama · Crear una tarea',[
[0,1,'add_todo()','create_code',False], [1,2,'create(título, descripción)','create_code',False], [2,3,'add, commit, refresh','transaction',False],
[3,2,'fila guardada','transaction',True], [2,1,'return as_view(todo)','view',True], [1,1,'load_todos()','flow_read',False], [1,0,'Reflex actualiza la lista','ui',True]],
'todo_form() dispara add_todo() al enviar. create() valida antes de guardar. add_todo() no utiliza el TodoView devuelto.','create_code')
read=seq('flow_read','Diagrama · Consultar y mostrar las tareas',[
[0,1,'load_todos()','read_code',False], [1,2,'initialize()','flow_init',False], [1,2,'list_all()','read_code',False],
[2,3,'select(Todo).order_by(...)','read_code',False], [2,1,'list[TodoView]','view',True], [1,1,'self.todos = resultado','state',True], [1,0,'rx.foreach(visible_todos)','ui_code',True]],
'on_load, Actualizar y los eventos de escritura usan load_todos(). list_all() transforma las filas con as_view().','read_code')
update=seq('flow_update','Diagrama · Editar una tarea',[
[0,1,'start_edit(id)','update',False], [0,1,'update_todo()','update_code',False], [1,2,'edit(id, título, descripción)','update_code',False],
[2,3,'get() + cambios + commit()','update_code',False], [2,1,'finaliza edit()','update',True], [1,1,'load_todos()','flow_read',False], [1,0,'Reflex actualiza la lista','ui',True]],
'Editar abre el diálogo con start_edit(). Guardar cambios dispara update_todo(). El id identifica la misma fila durante el recorrido.','update_code')
completed=seq('flow_completed','Diagrama · Marcar una tarea completada',[
[0,1,'toggle_complete()','completed_code',False], [1,2,'set_completed(id, checked)','completed_code',False], [2,3,'update() + commit()','completed_code',False],
[3,2,'resultado de la escritura','completed',True], [2,1,'finaliza set_completed()','completed',True], [1,1,'load_todos()','flow_read',False], [1,0,'Reflex actualiza la casilla','ui',True]],
'La casilla envía el id y checked. El repositorio asigna ese valor a completed y comprueba que rowcount sea 1.','completed_code')
delete=seq('flow_delete','Diagrama · Eliminar una tarea',[
[0,1,'ask_delete(id)','delete',False], [0,1,'delete_todo()','delete_code',False], [1,2,'delete(id)','delete_code',False],
[2,3,'get() + delete() + commit()','delete_code',False], [2,1,'finaliza delete()','delete',True], [1,1,'load_todos()','flow_read',False], [1,0,'Reflex actualiza la lista','ui',True]],
'Eliminar llama a ask_delete() y abre la confirmación. Solo Sí, eliminar dispara delete_todo() y solicita borrar la fila.','delete_code')
insert={'db_code':init,'create_code':create,'read_code':read,'update_code':update,'completed_code':completed,'delete_code':delete}
result=[]
for s in slides:
    if s['id']=='architecture':
        s['kind']='connection_map';s['title']='Diagrama · Conexiones entre archivos';s['subtitle']='Las funciones de interfaz activan eventos. Los eventos llaman al repositorio, que utiliza el motor y el modelo.'
    if s['id'] in insert: result.append(insert[s['id']])
    result.append(s)
(b/'slides-diagrams.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
s=(b/'build.mjs').read_text()
s=s.replace("pkg=path.join(b,'package')","pkg=path.join(b,'package-diagrams')")
s=s.replace("path.join(b,'slides.json')","path.join(b,'slides-diagrams.json')")
s=s.replace("execFileSync('convert',[path.join(b,'codigo/capturas.png'),'-crop','1100x620','+repage',path.join(b,'codigo/part-%02d.png')]);",'')
s=s.replace("path.join(b,'CRUD_interactivo_borrador.pptx')","path.join(b,'CRUD_diagramas_borrador.pptx')")
s=s.replace("path.join(b,'layout.json')","path.join(b,'layout-diagrams.json')")
s=s.replace("['db_code','Conexión e inicialización']","['flow_init','Diagrama de inicialización']").replace("['create_code','C · Crear una tarea']","['flow_create','C · Crear una tarea']").replace("['read_code','R · Consultar tareas']","['flow_read','R · Consultar tareas']").replace("['update_code','U · Editar textos']","['flow_update','U · Editar textos']").replace("['completed_code','U · Completar una tarea']","['flow_completed','U · Completar una tarea']").replace("['delete_code','D · Eliminar una tarea']","['flow_delete','D · Eliminar una tarea']")
# Shortcuts from the code and theory back to their matching sequence diagrams.
s=s.replace("if(i>0)text('Anterior'", "const diagram={db_code:'flow_init',engine:'flow_init',init:'flow_init',create_code:'flow_create',create:'flow_create',read_code:'flow_read',read:'flow_read',update_code:'flow_update',update:'flow_update',completed_code:'flow_completed',completed:'flow_completed',delete_code:'flow_delete',delete:'flow_delete'}[d.id];if(diagram)text('Ver diagrama',470,758,225,30,20,'63DCCA',true,diagram);if(i>0)text('Anterior'")
helper=r'''
function connector(x1,y1,x2,y2,{color='63DCCA',dash=false,arrow=true,from=null,to=null,fromIdx=3,toIdx=1}={}){
 const id=++shapeID, x=Math.min(x1,x2),y=Math.min(y1,y2),w=Math.abs(x2-x1),h=Math.abs(y2-y1);
 const flipped=(x2<x1?' flipH="1"':'')+(y2<y1?' flipV="1"':'');
 shapes.push(`<p:cxnSp><p:nvCxnSpPr><p:cNvPr id="${id}" name="${dash?'Resultado':'Llamada'} ${id}"/><p:cNvCxnSpPr>${from?`<a:stCxn id="${from}" idx="${fromIdx}"/>`:''}${to?`<a:endCxn id="${to}" idx="${toIdx}"/>`:''}</p:cNvCxnSpPr><p:nvPr/></p:nvCxnSpPr><p:spPr><a:xfrm${flipped}><a:off x="${E(x)}" y="${E(y)}"/><a:ext cx="${E(w)}" cy="${E(h)}"/></a:xfrm><a:prstGeom prst="line"><a:avLst/></a:prstGeom><a:ln w="${E(dash?2:2.5)}"><a:solidFill><a:srgbClr val="${color}"/></a:solidFill><a:prstDash val="${dash?'dash':'solid'}"/>${arrow?'<a:tailEnd type="triangle" w="med" len="med"/>':''}</a:ln></p:spPr><p:style><a:lnRef idx="0"><a:schemeClr val="accent1"/></a:lnRef><a:fillRef idx="0"><a:schemeClr val="accent1"/></a:fillRef><a:effectRef idx="0"><a:schemeClr val="accent1"/></a:effectRef><a:fontRef idx="minor"><a:schemeClr val="lt1"/></a:fontRef></p:style></p:cxnSp>`);
}
function diagramBox(label,detail,x,y,w,h,target){
 text(label+'\n'+detail,x,y,w,h,26,'E8EEF7',false,target,'1C293D');return shapeID;
}
function sequenceDiagram(d){
 const cols=[195,545,895,1245];
 d.lanes.forEach(([name,to],k)=>{
  text(name,cols[k]-148,201,300,43,25,'63DCCA',true,to);
  connector(cols[k],255,cols[k],667,{color:'475569',dash:true,arrow:false});
 });
 d.rows.forEach(([from,to,label,target,result],j)=>{
  const y=291+j*57,color=result?'F4CC7A':'63DCCA';
  if(from===to){
   connector(cols[from],y-6,cols[from]+70,y-6,{color,arrow:false,dash:result});
   connector(cols[from]+70,y-6,cols[from]+70,y+16,{color,arrow:false,dash:result});
   connector(cols[from]+70,y+16,cols[from],y+16,{color,dash:result});
   text(label,cols[from]+95,y-18,650,42,24,color,false,target);
  }else{
   const lo=Math.min(cols[from],cols[to]),span=Math.abs(cols[to]-cols[from]);
   connector(cols[from],y+14,cols[to],y+14,{color,dash:result});
   text(label,lo+14,y-21,span-20,35,23,color,false,target);
  }
 });
 text('Continua: llamada o acción',60,681,500,30,20,'63DCCA');
 text('Discontinua: resultado o vista',570,681,560,30,20,'F4CC7A');
 text(d.note,60,716,1320,44,19,'B8C7DB');
}
function connectionMap(){
 const main=[['todo_app.py','Interfaz Reflex','ui_code'],['todo_app.py','TodoState','state_code'],['repository.py','TodoRepository','repo_code'],['data/todos.db','Tabla todos','engine']];
 const xs=[55,400,745,1090],nodeIds=[];
 main.forEach(([a,desc,to],k)=>nodeIds.push(diagramBox(a,desc,xs[k],240,290,105,to)));
 for(let k=0;k<3;k++)connector(xs[k]+290,293,xs[k+1],293,{from:nodeIds[k],to:nodeIds[k+1]});
 text('evento',320,195,180,34,21,'63DCCA');text('llamada CRUD',635,195,210,34,21,'63DCCA');text('Session y SQL',985,195,220,34,21,'63DCCA');
 const database=diagramBox('database.py','get_engine()\ninit_database()',745,495,290,110,'db_code');
 const models=diagramBox('models.py','Modelo Todo',1090,495,290,110,'model_code');
 connector(890,345,890,495,{from:nodeIds[2],to:database,fromIdx:2,toIdx:0});
 text('usa el motor',905,400,200,36,23,'63DCCA');
 connector(1235,495,1235,345,{from:models,to:nodeIds[3],fromIdx:0,toIdx:2});
 text('estructura',1250,400,160,36,22,'63DCCA');
 connector(1090,326,1060,326,{color:'F4CC7A',dash:true,arrow:false});
 connector(1060,326,1060,444,{color:'F4CC7A',dash:true,arrow:false});
 connector(1060,444,545,444,{color:'F4CC7A',dash:true,arrow:false});
 connector(545,444,545,345,{color:'F4CC7A',dash:true});
 text('lectura: filas convertidas en TodoView',430,451,650,34,22,'F4CC7A');
 text('Tras escribir, el evento ejecuta load_todos() y Reflex vuelve a mostrar la lista.',60,651,1300,40,25,'F4CC7A',false,'flow_read');
 text('Recorridos: Inicialización',60,704,400,35,23,'63DCCA',false,'flow_init');
 text('Crear',520,704,150,35,23,'63DCCA',false,'flow_create');text('Leer',690,704,150,35,23,'63DCCA',false,'flow_read');
 text('Editar',860,704,150,35,23,'63DCCA',false,'flow_update');text('Completar',1030,704,180,35,23,'63DCCA',false,'flow_completed');text('Eliminar',1240,704,160,35,23,'63DCCA',false,'flow_delete');
}
'''
s=s.replace('let layouts=[];',helper+'\nlet layouts=[];')
s=s.replace("}else if(d.kind==='architecture'){", "}else if(d.kind==='sequence'){\n sequenceDiagram(d);\n }else if(d.kind==='connection_map'){\n connectionMap();\n }else if(d.kind==='architecture'){")
s=s.replace("return source+'\\n\\n'+(d.subtitle||'')", "if(d.rows)source+='\\nSecuencia: '+d.rows.map(r=>d.lanes[r[0]][0]+' llama o devuelve a '+d.lanes[r[1]][0]+': '+r[2]).join('\\n')+'\\n'+d.note;\n return source+'\\n\\n'+(d.subtitle||'')")
(b/'build-diagrams.mjs').write_text(s)
f=(b/'finalize.mjs').read_text().replace('CRUD_interactivo_borrador.pptx','CRUD_diagramas_borrador.pptx').replace('CRUD_Reflex_interactivo.pptx','CRUD_Reflex_interactivo_con_diagramas.pptx').replace("'33'","'39'").replace("validation.json","validation-diagrams.json")
(b/'finalize-diagrams.mjs').write_text(f)
print('Preparados',len(result),'slides, incluidos 6 diagramas de secuencia y un mapa de conexiones.')
