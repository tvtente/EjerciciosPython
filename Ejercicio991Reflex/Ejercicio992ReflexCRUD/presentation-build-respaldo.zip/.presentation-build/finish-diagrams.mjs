import {execFileSync} from 'node:child_process';
await import('./build-diagrams.mjs');
await import('./finalize-diagrams.mjs');
execFileSync('libreoffice',['-env:UserInstallation=file:///tmp/crud-ppt-lo-profile','--headless','--convert-to','pdf','--outdir','.presentation-build','entregables/CRUD_Reflex_interactivo_con_diagramas.pptx'],{stdio:'inherit'});
execFileSync('pdftoppm',['-scale-to','1440','-png','.presentation-build/CRUD_Reflex_interactivo_con_diagramas.pdf','.presentation-build/diagram-review/final'],{stdio:'inherit'});
