import path from 'node:path';
import { finalizePresentation } from '/home/tvt/.codex/plugins/cache/openai-primary-runtime/presentations/26.1030.10813/skills/presentations/container_tools/artifact_tool_utils.mjs';
const dir=process.cwd();
const skill='/home/tvt/.codex/plugins/cache/openai-primary-runtime/presentations/26.1030.10813/skills/presentations';
const result=await finalizePresentation({workspaceDir:dir,candidatePath:path.join(dir,'.presentation-build/CRUD_interactivo_borrador.pptx'),finalPath:path.join(dir,'entregables/CRUD_Reflex_interactivo.pptx'),pythonExecutable:'/usr/bin/python3',integrityValidatorPath:path.join(skill,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(skill,'container_tools/inspect_presentation_layout_geometry.py'),layoutArgs:['--expected-slide-size-emu','13716000,7715250','--expected-slide-count','33','--validate-heading-fit'],requiredNativeTableOwnerSlides:[],requiredNativeChartOwnerSlides:[],fontPolicy:{basis:'design',families:['DejaVu Sans']},verifyArtifactToolImport:false,receiptPath:path.join(dir,'.presentation-build/validation.json')});
console.log(JSON.stringify(result));
