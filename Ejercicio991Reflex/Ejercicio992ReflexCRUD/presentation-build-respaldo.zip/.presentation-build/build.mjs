import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
const root=process.cwd(), b=path.join(root,'.presentation-build'), pkg=path.join(b,'package');
const data=JSON.parse(fs.readFileSync(path.join(b,'slides.json'))), caps=JSON.parse(fs.readFileSync(path.join(b,'captures.json')));
execFileSync('convert',[path.join(b,'codigo/capturas.png'),'-crop','1100x620','+repage',path.join(b,'codigo/part-%02d.png')]);
caps.forEach((id,i)=>fs.copyFileSync(path.join(b,`codigo/part-${String(i).padStart(2,'0')}.png`),path.join(b,'codigo',id+'.png')));
const ids=Object.fromEntries(data.map((d,i)=>[d.id,i+1]));
const esc=v=>String(v).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const E=v=>Math.round(v*9525), W=1440,H=810;
const ns='xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"';
const relNS='http://schemas.openxmlformats.org/package/2006/relationships', types='http://schemas.openxmlformats.org/officeDocument/2006/relationships/';
const write=(name,text)=>{const dest=path.join(pkg,name);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,text);};
const xml=(s)=>'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'+s;
const emptyTree='<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>';
let shapes=[],rels=[],shapeID=1, records=[];
function link(id){let rid='rId'+(rels.length+1);rels.push({Id:rid,Type:types+'slide',Target:`slide${ids[id]}.xml`});return `<a:hlinkClick r:id="${rid}" action="ppaction://hlinksldjump"/>`;}
function text(value,x,y,w,h,size=26,color='E8EEF7',bold=false,target=null,fill=null){
 let id=++shapeID, l=target?link(target):'',paras=String(value).split('\n').map(line=>`<a:p><a:pPr marL="0" marR="0" indent="0"><a:lnSpc><a:spcPct val="112000"/></a:lnSpc></a:pPr><a:r><a:rPr lang="es-ES" sz="${Math.round(size*75)}" b="${bold?1:0}" dirty="0"><a:solidFill><a:srgbClr val="${color}"/></a:solidFill><a:latin typeface="DejaVu Sans"/>${l}</a:rPr><a:t xml:space="preserve">${esc(line)}</a:t></a:r><a:endParaRPr lang="es-ES" sz="${Math.round(size*75)}"/></a:p>`).join('');
 shapes.push(`<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="${esc(target?'Enlace a '+target:'Texto '+id)}">${l}</p:cNvPr><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="${E(x)}" y="${E(y)}"/><a:ext cx="${E(w)}" cy="${E(h)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>${fill?`<a:solidFill><a:srgbClr val="${fill}"/></a:solidFill>`:'<a:noFill/>'}<a:ln><a:noFill/></a:ln></p:spPr><p:txBody><a:bodyPr wrap="square" lIns="${E(fill?14:0)}" rIns="${E(fill?14:0)}" tIns="${E(fill?8:0)}" bIns="0" anchor="t"/><a:lstStyle/>${paras}</p:txBody></p:sp>`);
 records.push({text:value,x,y,w,h,target});
}
function image(file,x,y,w,h,target){let id=++shapeID,rid='rId'+(rels.length+1);rels.push({Id:rid,Type:types+'image',Target:'../media/'+file});let l=target?link(target):'';
 shapes.push(`<p:pic><p:nvPicPr><p:cNvPr id="${id}" name="Captura ${esc(file)}" descr="Fragmento del código del proyecto. Pulsa para abrir su explicación.">${l}</p:cNvPr><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="${rid}"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x="${E(x)}" y="${E(y)}"/><a:ext cx="${E(w)}" cy="${E(h)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/><a:ln><a:noFill/></a:ln></p:spPr></p:pic>`);
 fs.mkdirSync(path.join(pkg,'ppt/media'),{recursive:true});fs.copyFileSync(path.join(b,'codigo',file),path.join(pkg,'ppt/media',file));
}
function hotspot(x,y,w,h,target,label){let id=++shapeID,l=link(target);shapes.push(`<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="${esc(label)}">${l}</p:cNvPr><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="${E(x)}" y="${E(y)}"/><a:ext cx="${E(w)}" cy="${E(h)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="FFFFFF"><a:alpha val="0"/></a:srgbClr></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr></p:sp>`);}
function footer(d,i){text('Menú',55,758,100,30,20,'63DCCA',true,'menu');if(d.back)text('Volver al código',180,758,250,30,20,'63DCCA',true,d.back);if(i>0)text('Anterior',995,758,125,30,19,'A8B7CB',false,data[i-1].id);if(i<data.length-1)text('Siguiente',1130,758,130,30,19,'A8B7CB',false,data[i+1].id);text(`${i+1} / ${data.length}`,1300,758,100,30,18,'A8B7CB');}
function notes(d){let source=(d.refs||[]).join('\n');if(!source)source='Fuente principal: código local del proyecto Ejercicio992ReflexCRUD.\nArchivos: todo_app/todo_app.py, repository.py, models.py y database.py.';
 if(['model','engine','init','repo','transaction','migrations'].includes(d.id))source+='\nReferencia conceptual: https://sqlmodel.tiangolo.com/tutorial/create-db-and-table/\nhttps://reflex.dev/docs/database/overview/';
 if(['state','ui','filters'].includes(d.id))source+='\nReferencia conceptual: https://reflex.dev/docs/events/events-overview/';
 return source+'\n\n'+(d.subtitle||'')+'\n'+(d.points||[]).map(p=>p.join(': ')).join('\n')+(d.example?'\n'+d.example:'');
}
let layouts=[];
for(let i=0;i<data.length;i++){
 const d=data[i];shapes=[];rels=[{Id:'rId1',Type:types+'slideLayout',Target:'../slideLayouts/slideLayout1.xml'},{Id:'rId2',Type:types+'notesSlide',Target:`../notesSlides/notesSlide${i+1}.xml`}];shapeID=1;records=[];
 if(d.kind==='cover'){
 text('EJERCICIO 992',80,105,1000,35,22,'63DCCA',true);
 text('El código\nde tu CRUD',80,205,1250,200,76,'F5F8FC',true);
 text(d.subtitle,85,440,1100,50,34,'B8C7DB');
 text('Abrir el explorador',85,555,650,60,32,'63DCCA',true,'menu');
 text('En modo Presentación (F5), pulsa el código y los enlaces.\nCada explicación permite volver al fragmento de origen.',85,650,1200,75,23,'B8C7DB');
 }else{
 text(d.title,55,42,1330,65,42,'F5F8FC',true);
 text(d.subtitle,55,118,1320,73,23,'B8C7DB');
 if(d.kind==='menu'){
 const entries=[['architecture','Mapa del recorrido'],['model_code','Todo y TodoView'],['db_code','Conexión e inicialización'],['state_code','TodoState y eventos'],['repo_code','TodoRepository'],['create_code','C · Crear una tarea'],['read_code','R · Consultar tareas'],['update_code','U · Editar textos'],['completed_code','U · Completar una tarea'],['delete_code','D · Eliminar una tarea'],['ui_code','Funciones de interfaz'],['filters_code','Búsqueda y filtros'],['validation_code','Validación y errores'],['migrations','create_all y migraciones'],['exercise','Ejercicio del CRUD'],['glossary','Guía de símbolos']];
 entries.forEach(([to,label],k)=>{const col=k<8?0:1,row=k%8;text(String(k+1).padStart(2,'0'),65+col*680,215+row*61,60,42,23,'7B8FA9');text(label,130+col*680,215+row*61,590,43,27,'63DCCA',false,to);});
 }else if(d.kind==='architecture'){
 const steps=[['ui','01  Interfaz','todo_form() y todo_item()','Capturan lo que hace el usuario.'],['state','02  Estado','TodoState','El evento coordina la acción.'],['repo','03  Repositorio','TodoRepository','Consulta o escribe mediante Session.'],['model','04  Persistencia','Todo + SQLite','La tabla todos conserva los datos.']];
 steps.forEach(([to,head,name,desc],k)=>{let y=205+k*111;text(head,65,y,310,42,28,'63DCCA',true,to);text(name,390,y,960,40,28,'F5F8FC',true,to);text(desc,390,y+43,960,40,25,'B8C7DB');});
 text('Después de escribir: load_todos() vuelve a leer la BDD y actualiza self.todos.',65,672,1290,55,25,'F4CC7A');
 }else if(d.kind==='code'){
 image(d.image,45,180,1000,563.6,d.links[0][0]);
 // Transparent click areas over source regions give each principal symbol its own destination.
 if(d.id==='model_code')hotspot(45,420,1000,320,'view','Código de TodoView');
 if(d.id==='db_code')hotspot(45,430,1000,130,'init','Código de init_database');
 if(d.id==='state_code')hotspot(45,445,1000,290,'read','Código de load_todos');
 if(d.id==='repo_code'){hotspot(45,300,1000,52,'init','Código de initialize');hotspot(45,365,1000,120,'read','Código de list_all');}
 if(d.id==='create_code'){hotspot(45,540,1000,140,'transaction','Código de la sesión de creación');hotspot(45,516,1000,24,'validation','Código de validate_text');}
 text('EXPLICACIONES',1100,215,290,30,19,'A8B7CB',true);
 const labels={model:'Todo',view:'TodoView y as_view',engine:'get_engine()',init:'init_database()',migrations:'Migraciones',state:'TodoState',read:'Lectura de tareas',filters:'Filtros y @rx.var',repo:'TodoRepository',create:'Crear una tarea',transaction:'Session y commit',validation:'Validación',update:'Editar una tarea',completed:'Completar tarea',delete:'Eliminar tarea',ui:'Interfaz Reflex'};
 d.links.forEach(([to,label],k)=>text(labels[to]||label,1100,268+k*99,290,88,26,'63DCCA',true,to));
 const yy=d.links.length===3?575:520;text(d.summary,1100,yy,285,160,22,'DCE6F2');
 }else if(d.kind==='theory'){
 d.points.forEach(([head,body],k)=>{let y=222+k*124;text(head,65,y,320,95,28,'63DCCA',true);text(body,410,y,960,110,27,'E8EEF7');});
 text(d.example,65,632,1315,96,25,'F4CC7A');
 }else if(d.kind==='compare'){
 text(d.leftTitle,65,220,620,55,31,'63DCCA',true);text(d.rightTitle,750,220,620,55,31,'63DCCA',true);
 d.left.forEach((v,k)=>text(v,65,300+k*73,620,66,26));d.right.forEach((v,k)=>text(v,750,300+k*73,620,66,26));
 text(d.bottom,65,650,1300,70,27,'F4CC7A');
 }else if(d.kind==='exercise'){
 const rows=[['create_code','C · Añadir','Escribe «Preparar examen». create() guarda una fila nueva.'],['read_code','R · Consultar','Actualiza la página. list_all() recupera la tarea guardada.'],['update_code','U · Editar','Cambia el título. edit() conserva el mismo id.'],['completed_code','U · Completar','Marca la casilla. set_completed() cambia completed.'],['delete_code','D · Eliminar','Confirma el borrado. delete() elimina la fila.']];
 rows.forEach(([to,head,body],k)=>{text(head,65,215+k*91,300,60,29,'63DCCA',true,to);text(body,395,215+k*91,970,80,27);});
 text('Durante el recorrido, data/todos.db conserva los cambios confirmados.',65,686,1300,40,25,'F4CC7A');
 }else if(d.kind==='glossary'){
 const rows=[['model','Todo','Tabla y campos'],['view','TodoView / as_view','Datos para la pantalla'],['engine','get_engine','Motor y ruta de la BDD'],['init','init_database','Creación de tablas'],['state','TodoState','Eventos y datos de interfaz'],['repo','TodoRepository','Operaciones de persistencia'],['transaction','Session / commit','Trabajo y confirmación'],['ui','Funciones de interfaz','Componentes de Reflex'],['filters','@rx.var','Valores calculados'],['validation','validate_text / _report','Reglas y mensajes de error']];
 rows.forEach(([to,head,body],k)=>{let col=k<5?0:1,row=k%5,x=65+col*680,y=220+row*96;text(head,x,y,620,40,27,'63DCCA',true,to);text(body,x,y+39,620,39,24,'B8C7DB');});
 }
 footer(d,i);
 }
 layouts.push({slide:i+1,id:d.id,records});
 const noTransition='<p:transition advClick="0"/>';
 write(`ppt/slides/slide${i+1}.xml`,xml(`<p:sld ${ns}><p:cSld name="${esc(d.title)}"><p:bg><p:bgPr><a:solidFill><a:srgbClr val="101827"/></a:solidFill><a:effectLst/></p:bgPr></p:bg><p:spTree>${emptyTree}${shapes.join('')}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>${noTransition}</p:sld>`));
 write(`ppt/slides/_rels/slide${i+1}.xml.rels`,xml(`<Relationships xmlns="${relNS}">${rels.map(r=>`<Relationship Id="${r.Id}" Type="${r.Type}" Target="${r.Target}"/>`).join('')}</Relationships>`));
 const n=esc(notes(d));
 write(`ppt/notesSlides/notesSlide${i+1}.xml`,xml(`<p:notes ${ns}><p:cSld><p:spTree>${emptyTree}<p:sp><p:nvSpPr><p:cNvPr id="2" name="Notas"/><p:cNvSpPr/><p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/>${n.split('\n').map(p=>`<a:p><a:r><a:t>${p}</a:t></a:r></a:p>`).join('')}</p:txBody></p:sp></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:notes>`));
 write(`ppt/notesSlides/_rels/notesSlide${i+1}.xml.rels`,xml(`<Relationships xmlns="${relNS}"><Relationship Id="rId1" Type="${types}slide" Target="../slides/slide${i+1}.xml"/><Relationship Id="rId2" Type="${types}notesMaster" Target="../notesMasters/notesMaster1.xml"/></Relationships>`));
}
const colorMap='<p:clrMap accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" bg1="lt1" bg2="lt2" folHlink="folHlink" hlink="hlink" tx1="dk1" tx2="dk2"/>';
write('ppt/slideMasters/slideMaster1.xml',xml(`<p:sldMaster ${ns}><p:cSld><p:spTree>${emptyTree}</p:spTree></p:cSld>${colorMap}<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst><p:txStyles><p:titleStyle/><p:bodyStyle/><p:otherStyle/></p:txStyles></p:sldMaster>`));
write('ppt/slideMasters/_rels/slideMaster1.xml.rels',xml(`<Relationships xmlns="${relNS}"><Relationship Id="rId1" Type="${types}slideLayout" Target="../slideLayouts/slideLayout1.xml"/><Relationship Id="rId2" Type="${types}theme" Target="../theme/theme1.xml"/></Relationships>`));
write('ppt/slideLayouts/slideLayout1.xml',xml(`<p:sldLayout ${ns} type="blank" preserve="1"><p:cSld name="Vacío"><p:spTree>${emptyTree}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>`));
write('ppt/slideLayouts/_rels/slideLayout1.xml.rels',xml(`<Relationships xmlns="${relNS}"><Relationship Id="rId1" Type="${types}slideMaster" Target="../slideMasters/slideMaster1.xml"/></Relationships>`));
write('ppt/notesMasters/notesMaster1.xml',xml(`<p:notesMaster ${ns}><p:cSld><p:spTree>${emptyTree}</p:spTree></p:cSld>${colorMap}<p:notesStyle/></p:notesMaster>`));
write('ppt/notesMasters/_rels/notesMaster1.xml.rels',xml(`<Relationships xmlns="${relNS}"><Relationship Id="rId1" Type="${types}theme" Target="../theme/theme1.xml"/></Relationships>`));
const clr=[['dk1','101827'],['lt1','F5F8FC'],['dk2','1C293D'],['lt2','E8EEF7'],['accent1','63DCCA'],['accent2','F4CC7A'],['accent3','91B9F4'],['accent4','EBA1CC'],['accent5','B6D87A'],['accent6','D49BFF'],['hlink','63DCCA'],['folHlink','63DCCA']];
write('ppt/theme/theme1.xml',xml(`<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="CRUD"><a:themeElements><a:clrScheme name="CRUD">${clr.map(([n,v])=>`<a:${n}><a:srgbClr val="${v}"/></a:${n}>`).join('')}</a:clrScheme><a:fontScheme name="DejaVu Sans"><a:majorFont><a:latin typeface="DejaVu Sans"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="DejaVu Sans"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme><a:fmtScheme name="Default"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst><a:lnStyleLst>${[1,2,3].map(n=>`<a:ln w="${n*9525}"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>`).join('')}</a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>`));
write('ppt/presentation.xml',xml(`<p:presentation ${ns} saveSubsetFonts="1"><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:notesMasterIdLst><p:notesMasterId r:id="rId2"/></p:notesMasterIdLst><p:sldIdLst>${data.map((_,i)=>`<p:sldId id="${256+i}" r:id="rId${3+i}"/>`).join('')}</p:sldIdLst><p:sldSz cx="${E(W)}" cy="${E(H)}"/><p:notesSz cx="6858000" cy="9144000"/><p:defaultTextStyle/></p:presentation>`));
write('ppt/_rels/presentation.xml.rels',xml(`<Relationships xmlns="${relNS}"><Relationship Id="rId1" Type="${types}slideMaster" Target="slideMasters/slideMaster1.xml"/><Relationship Id="rId2" Type="${types}notesMaster" Target="notesMasters/notesMaster1.xml"/>${data.map((_,i)=>`<Relationship Id="rId${i+3}" Type="${types}slide" Target="slides/slide${i+1}.xml"/>`).join('')}</Relationships>`));
write('_rels/.rels',xml(`<Relationships xmlns="${relNS}"><Relationship Id="rId1" Type="${types}officeDocument" Target="ppt/presentation.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="${types}extended-properties" Target="docProps/app.xml"/></Relationships>`));
write('docProps/core.xml',xml('<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>El código de tu CRUD</dc:title><dc:subject>Guía interactiva del proyecto Reflex</dc:subject><dc:creator>Codex</dc:creator><dc:description>Capturas del código y navegación interna entre símbolos y teoría.</dc:description></cp:coreProperties>'));
write('docProps/app.xml',xml(`<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>PowerPoint</Application><PresentationFormat>On-screen Show (16:9)</PresentationFormat><Slides>${data.length}</Slides><Notes>${data.length}</Notes></Properties>`));
const overrides=[['/ppt/presentation.xml','presentation.main'],['/ppt/slideMasters/slideMaster1.xml','slideMaster'],['/ppt/slideLayouts/slideLayout1.xml','slideLayout'],['/ppt/notesMasters/notesMaster1.xml','notesMaster'],['/ppt/theme/theme1.xml','theme'],...data.flatMap((_,i)=>[[`/ppt/slides/slide${i+1}.xml`,'slide'],[`/ppt/notesSlides/notesSlide${i+1}.xml`,'notesSlide']])];
write('[Content_Types].xml',xml(`<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/>${overrides.map(([n,t])=>`<Override PartName="${n}" ContentType="application/vnd.openxmlformats-officedocument.${t==='theme'?'theme':('presentationml.'+t)}+xml"/>`).join('')}<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>`));
fs.writeFileSync(path.join(b,'layout.json'),JSON.stringify(layouts,null,2));
execFileSync('python3',['-c',`import zipfile,pathlib\np=pathlib.Path(${JSON.stringify(pkg)})\nwith zipfile.ZipFile(${JSON.stringify(path.join(b,'CRUD_interactivo_borrador.pptx'))},'w',zipfile.ZIP_DEFLATED) as z:\n for f in p.rglob('*'):\n  if f.is_file(): z.write(f,f.relative_to(p))`]);
console.log('PPTX generado:',data.length,'diapositivas');
